npm install aws-xray-sdk

chmod a+r *

zip -r funcion.zip .
