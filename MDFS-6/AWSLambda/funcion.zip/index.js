const AWSXRay = requier("aws-xray-sdk-core");
const AWS = AWSXRay.captureAWS(require("aws-sdk"));
const S3 = new AWS.S3();

exports.handler = async function (event) {
  return S3.lisrbuckets().promise();
};
